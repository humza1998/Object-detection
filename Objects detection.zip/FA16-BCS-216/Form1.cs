﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FA16_BCS_216
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); //this is used to call the default constructor of user control
        }
        private void button1_Click(object sender, EventArgs e) //this button will allow to open any picture from computer
        {
            OpenFileDialog file = new OpenFileDialog();
            if(file.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(file.FileName);
            }
        }
        private void button2_Click(object sender, EventArgs e) // this button will allow to perform action on the picture
        {
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            int index = 1;
            int[,] currentPosition = new int[bmp.Height, bmp.Width];  // 2D arrays for assigning different positions  
            int[,] leftPosition = new int[bmp.Height, bmp.Width];
            int[,] upperPosition = new int[bmp.Height, bmp.Width];
             
            for (int i = 1; i < bmp.Height - 1; i++) //Scan the image vertically
            {
                for (int j = 1; j < bmp.Width - 1; j++) // Scan the image horizontally
                {
                    if (bmp.GetPixel(j, i) == Color.Black || bmp.GetPixel(j, i).R < 10) //checking for black background
                    {
                        upperPosition[i, j] = currentPosition[i - 1, j];
                        leftPosition[i, j] = currentPosition[i, j - 1];
                        if (upperPosition[i, j] == 0 && leftPosition[i, j] == 0)
                        {
                            currentPosition[i, j] = index;       // If upper side and left side have zero value than set index to current
                        }
                        else if (upperPosition[i, j] == 0 && leftPosition[i, j] != 0 || upperPosition[i, j] != 0 && leftPosition[i, j] == 0)
                        {
                            if (upperPosition[i, j] != 0)
                            {
                                currentPosition[i, j] = upperPosition[i, j];
                            }
                            else
                            {
                                currentPosition[i, j] = leftPosition[i, j];
                            }
                        }
                        else if(leftPosition[i, j] == upperPosition[i, j] && leftPosition[i, j] != 0 && upperPosition[i, j] != 0)
                        {
                            currentPosition[i, j] = leftPosition[i, j]; //If the points are same
                        }
                        else if(leftPosition[i, j] != upperPosition[i, j] && leftPosition[i, j] != 0 && upperPosition[i, j] != 0)
                        {
                            if(upperPosition[i, j] < leftPosition[i, j]) //If the points are not same
                            {
                                currentPosition[i, j] = upperPosition[i, j];
                            }
                            else
                            {
                                currentPosition[i, j] = leftPosition[i, j];
                            }
                        }
                    }
                }
            }
            int color = currentPosition.Cast<int>().Max();
            Console.WriteLine(color);
            Color[] List = new Color[color];  //This will choose random colors for detection
            Random rand = new Random();
            for(int i = 0; i < color; i++)
            {
               List[i] = Color.FromArgb(rand.Next(0, 256), rand.Next(0, 256), rand.Next(0, 256)); //selecting random colors
            }
            for(int y = 0; y < bmp.Height; y++)
            {
               for(int x = 0; x < bmp.Width; x++)
                {
                  if(currentPosition[y, x]!= 0)
                  {
                     bmp.SetPixel(x, y, List[currentPosition[y, x] - 1]);
                  }
                }
            }
            pictureBox1.Image = bmp;
            }
    }
}
